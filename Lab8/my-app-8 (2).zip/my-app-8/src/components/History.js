import { createBrowserHistory } from "@remix-run/router";

const customHistory = createBrowserHistory();
export default customHistory;