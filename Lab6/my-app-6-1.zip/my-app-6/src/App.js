import './App.css';
import StudentList from './components/StudentList';

function App() {
    return (
        <>
            <StudentList />
        </>
    );
}

export default App;
